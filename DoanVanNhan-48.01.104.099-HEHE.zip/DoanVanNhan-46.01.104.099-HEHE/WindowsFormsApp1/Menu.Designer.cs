﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonPalette1 = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this.trangChủToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lậpHợpĐồngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lậpHóaĐonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.traCứuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tàiKhoantToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menu_tchopdong = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_tchoadon = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_tcnhanvien = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_lbc = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_bcdt = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lb_name = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPalette1
            // 
            this.kryptonPalette1.ButtonSpecs.FormClose.Image = global::WindowsFormsApp1.Properties.Resources.btn_red__3_;
            this.kryptonPalette1.ButtonSpecs.FormClose.ImageStates.ImagePressed = global::WindowsFormsApp1.Properties.Resources.btn_red__2_;
            this.kryptonPalette1.ButtonSpecs.FormClose.ImageStates.ImageTracking = global::WindowsFormsApp1.Properties.Resources.btn_red__2_;
            this.kryptonPalette1.ButtonSpecs.FormMax.Image = global::WindowsFormsApp1.Properties.Resources.btn_yellow__2_;
            this.kryptonPalette1.ButtonSpecs.FormMax.ImageStates.ImageCheckedNormal = global::WindowsFormsApp1.Properties.Resources.btn_yellow__2_;
            this.kryptonPalette1.ButtonSpecs.FormMax.ImageStates.ImageCheckedPressed = global::WindowsFormsApp1.Properties.Resources.btn_yellow__2_;
            this.kryptonPalette1.ButtonSpecs.FormMax.ImageStates.ImageCheckedTracking = global::WindowsFormsApp1.Properties.Resources.btn_yellow__2_;
            this.kryptonPalette1.ButtonSpecs.FormMax.ImageStates.ImageDisabled = global::WindowsFormsApp1.Properties.Resources.btn_yellow__2_;
            this.kryptonPalette1.ButtonSpecs.FormMax.ImageStates.ImageNormal = global::WindowsFormsApp1.Properties.Resources.btn_yellow__2_;
            this.kryptonPalette1.ButtonSpecs.FormMax.ImageStates.ImagePressed = global::WindowsFormsApp1.Properties.Resources.btn_yellow1;
            this.kryptonPalette1.ButtonSpecs.FormMax.ImageStates.ImageTracking = global::WindowsFormsApp1.Properties.Resources.btn_yellow1;
            this.kryptonPalette1.ButtonSpecs.FormMin.Image = global::WindowsFormsApp1.Properties.Resources.btn_green__2_;
            this.kryptonPalette1.ButtonSpecs.FormMin.ImageStates.ImagePressed = global::WindowsFormsApp1.Properties.Resources.btn_green1;
            this.kryptonPalette1.ButtonSpecs.FormMin.ImageStates.ImageTracking = global::WindowsFormsApp1.Properties.Resources.btn_green1;
            this.kryptonPalette1.ButtonSpecs.FormRestore.Image = global::WindowsFormsApp1.Properties.Resources.btn_yellow__2_;
            this.kryptonPalette1.ButtonSpecs.FormRestore.ImageStates.ImagePressed = global::WindowsFormsApp1.Properties.Resources.btn_yellow1;
            this.kryptonPalette1.ButtonSpecs.FormRestore.ImageStates.ImageTracking = global::WindowsFormsApp1.Properties.Resources.btn_yellow1;
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateNormal.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateNormal.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateNormal.Border.Width = 0;
            this.kryptonPalette1.ButtonStyles.ButtonForm.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StatePressed.Border.Width = 0;
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonForm.StateTracking.Border.Width = 0;
            this.kryptonPalette1.ButtonStyles.ButtonFormClose.StateNormal.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonFormClose.StateNormal.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonFormClose.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonFormClose.StateNormal.Border.Width = 0;
            this.kryptonPalette1.ButtonStyles.ButtonFormClose.StatePressed.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonFormClose.StatePressed.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonFormClose.StatePressed.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonFormClose.StatePressed.Border.Width = 0;
            this.kryptonPalette1.ButtonStyles.ButtonFormClose.StateTracking.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonFormClose.StateTracking.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.ButtonStyles.ButtonFormClose.StateTracking.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.ButtonStyles.ButtonFormClose.StateTracking.Border.Width = 0;
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.GraphicsHint = ComponentFactory.Krypton.Toolkit.PaletteGraphicsHint.None;
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Rounding = 15;
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Width = 0;
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.Back.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.Back.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.ButtonEdgeInset = 10;
            this.kryptonPalette1.HeaderStyles.HeaderForm.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, -1, -1, -1);
            // 
            // trangChủToolStripMenuItem
            // 
            this.trangChủToolStripMenuItem.AutoSize = false;
            this.trangChủToolStripMenuItem.Image = global::WindowsFormsApp1.Properties.Resources.home_menu;
            this.trangChủToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.trangChủToolStripMenuItem.Name = "trangChủToolStripMenuItem";
            this.trangChủToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.trangChủToolStripMenuItem.Size = new System.Drawing.Size(150, 55);
            this.trangChủToolStripMenuItem.Text = "Trang Chủ";
            this.trangChủToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // thôngTinToolStripMenuItem
            // 
            this.thôngTinToolStripMenuItem.AutoSize = false;
            this.thôngTinToolStripMenuItem.Image = global::WindowsFormsApp1.Properties.Resources.infor_menu;
            this.thôngTinToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.thôngTinToolStripMenuItem.Name = "thôngTinToolStripMenuItem";
            this.thôngTinToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.thôngTinToolStripMenuItem.Size = new System.Drawing.Size(150, 55);
            this.thôngTinToolStripMenuItem.Text = "Thông Tin";
            this.thôngTinToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.thôngTinToolStripMenuItem.Click += new System.EventHandler(this.thôngTinToolStripMenuItem_Click);
            // 
            // lậpHợpĐồngToolStripMenuItem
            // 
            this.lậpHợpĐồngToolStripMenuItem.AutoSize = false;
            this.lậpHợpĐồngToolStripMenuItem.Image = global::WindowsFormsApp1.Properties.Resources.create_menu;
            this.lậpHợpĐồngToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lậpHợpĐồngToolStripMenuItem.Name = "lậpHợpĐồngToolStripMenuItem";
            this.lậpHợpĐồngToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.lậpHợpĐồngToolStripMenuItem.Size = new System.Drawing.Size(150, 55);
            this.lậpHợpĐồngToolStripMenuItem.Text = "Lập Hợp Đồng";
            this.lậpHợpĐồngToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lậpHợpĐồngToolStripMenuItem.Click += new System.EventHandler(this.lậpHợpĐồngToolStripMenuItem_Click);
            // 
            // lậpHóaĐonToolStripMenuItem
            // 
            this.lậpHóaĐonToolStripMenuItem.AutoSize = false;
            this.lậpHóaĐonToolStripMenuItem.Image = global::WindowsFormsApp1.Properties.Resources.save_menu;
            this.lậpHóaĐonToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lậpHóaĐonToolStripMenuItem.Name = "lậpHóaĐonToolStripMenuItem";
            this.lậpHóaĐonToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.lậpHóaĐonToolStripMenuItem.Size = new System.Drawing.Size(150, 55);
            this.lậpHóaĐonToolStripMenuItem.Text = "Lập Hóa Đơn";
            this.lậpHóaĐonToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lậpHóaĐonToolStripMenuItem.Click += new System.EventHandler(this.lậpHóaĐonToolStripMenuItem_Click);
            // 
            // nhânViênToolStripMenuItem
            // 
            this.nhânViênToolStripMenuItem.AutoSize = false;
            this.nhânViênToolStripMenuItem.Image = global::WindowsFormsApp1.Properties.Resources.people_menu;
            this.nhânViênToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nhânViênToolStripMenuItem.Name = "nhânViênToolStripMenuItem";
            this.nhânViênToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.nhânViênToolStripMenuItem.Size = new System.Drawing.Size(150, 55);
            this.nhânViênToolStripMenuItem.Text = "Nhân Viên";
            this.nhânViênToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nhânViênToolStripMenuItem.Click += new System.EventHandler(this.nhânViênToolStripMenuItem_Click);
            // 
            // traCứuToolStripMenuItem
            // 
            this.traCứuToolStripMenuItem.AutoSize = false;
            this.traCứuToolStripMenuItem.Image = global::WindowsFormsApp1.Properties.Resources.find;
            this.traCứuToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.traCứuToolStripMenuItem.Name = "traCứuToolStripMenuItem";
            this.traCứuToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.traCứuToolStripMenuItem.Size = new System.Drawing.Size(150, 55);
            this.traCứuToolStripMenuItem.Text = "Tra Cứu";
            this.traCứuToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.traCứuToolStripMenuItem.Click += new System.EventHandler(this.traCứuToolStripMenuItem_Click);
            // 
            // báoCáoToolStripMenuItem
            // 
            this.báoCáoToolStripMenuItem.AutoSize = false;
            this.báoCáoToolStripMenuItem.Image = global::WindowsFormsApp1.Properties.Resources.report;
            this.báoCáoToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.báoCáoToolStripMenuItem.Name = "báoCáoToolStripMenuItem";
            this.báoCáoToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.báoCáoToolStripMenuItem.Size = new System.Drawing.Size(150, 55);
            this.báoCáoToolStripMenuItem.Text = "Báo Cáo";
            this.báoCáoToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.báoCáoToolStripMenuItem.Click += new System.EventHandler(this.báoCáoToolStripMenuItem_Click);
            // 
            // tàiKhoantToolStripMenuItem
            // 
            this.tàiKhoantToolStripMenuItem.AutoSize = false;
            this.tàiKhoantToolStripMenuItem.Checked = true;
            this.tàiKhoantToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tàiKhoantToolStripMenuItem.Image = global::WindowsFormsApp1.Properties.Resources.account;
            this.tàiKhoantToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tàiKhoantToolStripMenuItem.Name = "tàiKhoantToolStripMenuItem";
            this.tàiKhoantToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.tàiKhoantToolStripMenuItem.Size = new System.Drawing.Size(150, 55);
            this.tàiKhoantToolStripMenuItem.Text = "Tài Khoản";
            this.tàiKhoantToolStripMenuItem.Click += new System.EventHandler(this.tàiKhoantToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(252)))), ((int)(((byte)(252)))));
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trangChủToolStripMenuItem,
            this.thôngTinToolStripMenuItem,
            this.lậpHợpĐồngToolStripMenuItem,
            this.lậpHóaĐonToolStripMenuItem,
            this.nhânViênToolStripMenuItem,
            this.traCứuToolStripMenuItem,
            this.menu_tchopdong,
            this.menu_tchoadon,
            this.menu_tcnhanvien,
            this.báoCáoToolStripMenuItem,
            this.menu_lbc,
            this.menu_bcdt,
            this.tàiKhoantToolStripMenuItem,
            this.đăngXuấtToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.ShowItemToolTips = true;
            this.menuStrip1.Size = new System.Drawing.Size(165, 944);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "Hello";
            this.menuStrip1.UseWaitCursor = true;
            // 
            // menu_tchopdong
            // 
            this.menu_tchopdong.Image = global::WindowsFormsApp1.Properties.Resources.circle_10238096;
            this.menu_tchopdong.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_tchopdong.Name = "menu_tchopdong";
            this.menu_tchopdong.Padding = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.menu_tchopdong.Size = new System.Drawing.Size(194, 39);
            this.menu_tchopdong.Text = "Tra Cứu Hợp Đồng";
            this.menu_tchopdong.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_tchopdong.Visible = false;
            this.menu_tchopdong.Click += new System.EventHandler(this.menu_tchopdong_Click);
            // 
            // menu_tchoadon
            // 
            this.menu_tchoadon.Image = global::WindowsFormsApp1.Properties.Resources.circle_10238096;
            this.menu_tchoadon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_tchoadon.Name = "menu_tchoadon";
            this.menu_tchoadon.Padding = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.menu_tchoadon.Size = new System.Drawing.Size(194, 39);
            this.menu_tchoadon.Text = "Tra Cứu Hóa Đơn";
            this.menu_tchoadon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_tchoadon.Visible = false;
            this.menu_tchoadon.Click += new System.EventHandler(this.menu_tchoadon_Click);
            // 
            // menu_tcnhanvien
            // 
            this.menu_tcnhanvien.Image = global::WindowsFormsApp1.Properties.Resources.circle_10238096;
            this.menu_tcnhanvien.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_tcnhanvien.Name = "menu_tcnhanvien";
            this.menu_tcnhanvien.Padding = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.menu_tcnhanvien.Size = new System.Drawing.Size(194, 39);
            this.menu_tcnhanvien.Text = "Tra Cứu Nhân Viên";
            this.menu_tcnhanvien.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_tcnhanvien.Visible = false;
            this.menu_tcnhanvien.Click += new System.EventHandler(this.menu_tcnhanvien_Click);
            // 
            // menu_lbc
            // 
            this.menu_lbc.Image = global::WindowsFormsApp1.Properties.Resources.circle_10238096;
            this.menu_lbc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_lbc.Name = "menu_lbc";
            this.menu_lbc.Padding = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.menu_lbc.Size = new System.Drawing.Size(194, 39);
            this.menu_lbc.Text = "Lập Báo Cáo";
            this.menu_lbc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_lbc.Visible = false;
            this.menu_lbc.Click += new System.EventHandler(this.menu_lbc_Click);
            // 
            // menu_bcdt
            // 
            this.menu_bcdt.Image = global::WindowsFormsApp1.Properties.Resources.circle_10238096;
            this.menu_bcdt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_bcdt.Name = "menu_bcdt";
            this.menu_bcdt.Padding = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.menu_bcdt.Size = new System.Drawing.Size(194, 39);
            this.menu_bcdt.Text = "Báo Cáo Doanh Thu";
            this.menu_bcdt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu_bcdt.Visible = false;
            this.menu_bcdt.Click += new System.EventHandler(this.menu_bcdt_Click);
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Image = global::WindowsFormsApp1.Properties.Resources.logout_4210119;
            this.đăngXuấtToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(134, 39);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng Xuất";
            this.đăngXuấtToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // lb_name
            // 
            this.lb_name.Dock = System.Windows.Forms.DockStyle.Top;
            this.lb_name.Location = new System.Drawing.Point(165, 0);
            this.lb_name.Name = "lb_name";
            this.lb_name.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.ProfessionalSystem;
            this.lb_name.Size = new System.Drawing.Size(1413, 38);
            this.lb_name.StateCommon.ShortText.Color1 = System.Drawing.Color.Black;
            this.lb_name.StateCommon.ShortText.Color2 = System.Drawing.Color.Black;
            this.lb_name.StateCommon.ShortText.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_name.TabIndex = 1;
            this.lb_name.Values.ImageTransparentColor = System.Drawing.Color.White;
            this.lb_name.Values.Text = "User Name";
            this.lb_name.Paint += new System.Windows.Forms.PaintEventHandler(this.lb_name_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.image_menu;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1578, 944);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Palette = this.kryptonPalette1;
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý tiệc cưới";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonPalette kryptonPalette1;
        private System.Windows.Forms.ToolStripMenuItem trangChủToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lậpHợpĐồngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lậpHóaĐonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem traCứuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tàiKhoantToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menu_tchopdong;
        private System.Windows.Forms.ToolStripMenuItem menu_tchoadon;
        private System.Windows.Forms.ToolStripMenuItem menu_tcnhanvien;
        private System.Windows.Forms.ToolStripMenuItem menu_lbc;
        private System.Windows.Forms.ToolStripMenuItem menu_bcdt;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel lb_name;
    }
}

