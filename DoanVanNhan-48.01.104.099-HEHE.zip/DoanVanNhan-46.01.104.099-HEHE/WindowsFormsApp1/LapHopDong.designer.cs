﻿namespace QL_TiecCuoi
{
    partial class LapHopDong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dateTimePickerNgayLap = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerNgayToChuc = new System.Windows.Forms.DateTimePicker();
            this.textBoxTienCoc = new System.Windows.Forms.TextBox();
            this.labelTienCoc = new System.Windows.Forms.Label();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxDienThoai = new System.Windows.Forms.TextBox();
            this.textBoxDiaChi = new System.Windows.Forms.TextBox();
            this.textBoxTenCoDau = new System.Windows.Forms.TextBox();
            this.textBoxTenChuRe = new System.Windows.Forms.TextBox();
            this.textBoxTenKhachHang = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxTenNhanVien = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxCa = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.comboBoxDichVu = new System.Windows.Forms.ComboBox();
            this.comboBoxThucDon = new System.Windows.Forms.ComboBox();
            this.textBoxSLNhanVien = new System.Windows.Forms.TextBox();
            this.textBoxSoLuongBan = new System.Windows.Forms.TextBox();
            this.comboBoxLoaiSanh = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.kryptonPalette1 = new ComponentFactory.Krypton.Toolkit.KryptonPalette(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dateTimePickerNgayLap);
            this.groupBox1.Controls.Add(this.dateTimePickerNgayToChuc);
            this.groupBox1.Controls.Add(this.textBoxTienCoc);
            this.groupBox1.Controls.Add(this.labelTienCoc);
            this.groupBox1.Controls.Add(this.textBoxEmail);
            this.groupBox1.Controls.Add(this.textBoxDienThoai);
            this.groupBox1.Controls.Add(this.textBoxDiaChi);
            this.groupBox1.Controls.Add(this.textBoxTenCoDau);
            this.groupBox1.Controls.Add(this.textBoxTenChuRe);
            this.groupBox1.Controls.Add(this.textBoxTenKhachHang);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.groupBox1.Location = new System.Drawing.Point(13, 59);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(538, 557);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin khách hàng";
            // 
            // dateTimePickerNgayLap
            // 
            this.dateTimePickerNgayLap.Location = new System.Drawing.Point(183, 38);
            this.dateTimePickerNgayLap.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePickerNgayLap.Name = "dateTimePickerNgayLap";
            this.dateTimePickerNgayLap.Size = new System.Drawing.Size(336, 30);
            this.dateTimePickerNgayLap.TabIndex = 31;
            // 
            // dateTimePickerNgayToChuc
            // 
            this.dateTimePickerNgayToChuc.Location = new System.Drawing.Point(183, 440);
            this.dateTimePickerNgayToChuc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePickerNgayToChuc.Name = "dateTimePickerNgayToChuc";
            this.dateTimePickerNgayToChuc.Size = new System.Drawing.Size(336, 30);
            this.dateTimePickerNgayToChuc.TabIndex = 30;
            // 
            // textBoxTienCoc
            // 
            this.textBoxTienCoc.Location = new System.Drawing.Point(183, 506);
            this.textBoxTienCoc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTienCoc.Name = "textBoxTienCoc";
            this.textBoxTienCoc.Size = new System.Drawing.Size(336, 30);
            this.textBoxTienCoc.TabIndex = 28;
            this.textBoxTienCoc.TextChanged += new System.EventHandler(this.textBoxTienCoc_TextChanged);
            this.textBoxTienCoc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTienCoc_KeyPress);
            // 
            // labelTienCoc
            // 
            this.labelTienCoc.AutoSize = true;
            this.labelTienCoc.ForeColor = System.Drawing.SystemColors.InfoText;
            this.labelTienCoc.Location = new System.Drawing.Point(9, 503);
            this.labelTienCoc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTienCoc.Name = "labelTienCoc";
            this.labelTienCoc.Size = new System.Drawing.Size(114, 25);
            this.labelTienCoc.TabIndex = 27;
            this.labelTienCoc.Text = "Đặt tiền cọc";
            this.labelTienCoc.Click += new System.EventHandler(this.label20_Click);
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(183, 382);
            this.textBoxEmail.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(336, 30);
            this.textBoxEmail.TabIndex = 25;
            // 
            // textBoxDienThoai
            // 
            this.textBoxDienThoai.Location = new System.Drawing.Point(183, 320);
            this.textBoxDienThoai.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxDienThoai.Name = "textBoxDienThoai";
            this.textBoxDienThoai.Size = new System.Drawing.Size(336, 30);
            this.textBoxDienThoai.TabIndex = 24;
            this.textBoxDienThoai.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxDienThoai_KeyPress);
            // 
            // textBoxDiaChi
            // 
            this.textBoxDiaChi.Location = new System.Drawing.Point(183, 262);
            this.textBoxDiaChi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxDiaChi.Name = "textBoxDiaChi";
            this.textBoxDiaChi.Size = new System.Drawing.Size(336, 30);
            this.textBoxDiaChi.TabIndex = 23;
            // 
            // textBoxTenCoDau
            // 
            this.textBoxTenCoDau.AutoCompleteCustomSource.AddRange(new string[] {
            "Dương",
            "Phạm",
            "Trần",
            "Nguyễn",
            "Lê",
            "Trịnh",
            "Phan",
            "Vũ",
            "Võ",
            "Đặng",
            "Bùi",
            "Đỗ",
            "Hồ",
            "Ngô",
            "Đoàn",
            "Thân",
            "Trương",
            "Quách",
            "Bạch",
            "Lý",
            "Đào",
            "Hà",
            "Hoàng",
            "Huynh",
            "Hồ"});
            this.textBoxTenCoDau.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBoxTenCoDau.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBoxTenCoDau.Location = new System.Drawing.Point(183, 205);
            this.textBoxTenCoDau.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTenCoDau.Name = "textBoxTenCoDau";
            this.textBoxTenCoDau.Size = new System.Drawing.Size(336, 30);
            this.textBoxTenCoDau.TabIndex = 22;
            this.textBoxTenCoDau.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTenCoDau_KeyPress);
            // 
            // textBoxTenChuRe
            // 
            this.textBoxTenChuRe.AutoCompleteCustomSource.AddRange(new string[] {
            "Dương",
            "Phạm",
            "Trần",
            "Nguyễn",
            "Lê",
            "Trịnh",
            "Phan",
            "Vũ",
            "Võ",
            "Đặng",
            "Bùi",
            "Đỗ",
            "Hồ",
            "Ngô",
            "Đoàn",
            "Thân",
            "Trương",
            "Quách",
            "Bạch",
            "Lý",
            "Đào",
            "Hà",
            "Hoàng",
            "Huynh",
            "Hồ"});
            this.textBoxTenChuRe.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBoxTenChuRe.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBoxTenChuRe.Location = new System.Drawing.Point(183, 148);
            this.textBoxTenChuRe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTenChuRe.Name = "textBoxTenChuRe";
            this.textBoxTenChuRe.Size = new System.Drawing.Size(336, 30);
            this.textBoxTenChuRe.TabIndex = 21;
            this.textBoxTenChuRe.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTenChuRe_KeyPress);
            // 
            // textBoxTenKhachHang
            // 
            this.textBoxTenKhachHang.AutoCompleteCustomSource.AddRange(new string[] {
            "Dương",
            "Phạm",
            "Trần",
            "Nguyễn",
            "Lê",
            "Trịnh",
            "Phan",
            "Vũ",
            "Võ",
            "Đặng",
            "Bùi",
            "Đỗ",
            "Hồ",
            "Ngô",
            "Đoàn",
            "Thân",
            "Trương",
            "Quách",
            "Bạch",
            "",
            "Lý",
            "Đào",
            "Hà",
            "Hoàng",
            "Huynh",
            "Hồ"});
            this.textBoxTenKhachHang.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBoxTenKhachHang.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBoxTenKhachHang.Location = new System.Drawing.Point(183, 97);
            this.textBoxTenKhachHang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTenKhachHang.Name = "textBoxTenKhachHang";
            this.textBoxTenKhachHang.Size = new System.Drawing.Size(336, 30);
            this.textBoxTenKhachHang.TabIndex = 20;
            this.textBoxTenKhachHang.TextChanged += new System.EventHandler(this.textBoxNgayLap_TextChanged);
            this.textBoxTenKhachHang.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxTenKhachHang_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label11.Location = new System.Drawing.Point(9, 448);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(126, 25);
            this.label11.TabIndex = 19;
            this.label11.Text = "Ngày tổ chức";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label10.Location = new System.Drawing.Point(9, 391);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 25);
            this.label10.TabIndex = 18;
            this.label10.Text = "Email";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label9.Location = new System.Drawing.Point(9, 325);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 25);
            this.label9.TabIndex = 17;
            this.label9.Text = "Điện thoại";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label8.Location = new System.Drawing.Point(9, 266);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 25);
            this.label8.TabIndex = 16;
            this.label8.Text = "Địa chỉ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label7.Location = new System.Drawing.Point(9, 209);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 25);
            this.label7.TabIndex = 15;
            this.label7.Text = "Họ tên cô dâu";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label6.Location = new System.Drawing.Point(9, 152);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 25);
            this.label6.TabIndex = 14;
            this.label6.Text = "Họ tên chú rể";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label5.Location = new System.Drawing.Point(9, 102);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 25);
            this.label5.TabIndex = 13;
            this.label5.Text = "Tên khách hàng";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label4.Location = new System.Drawing.Point(9, 46);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 25);
            this.label4.TabIndex = 12;
            this.label4.Text = "Ngày lập";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBoxTenNhanVien);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.comboBoxCa);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.comboBoxDichVu);
            this.groupBox2.Controls.Add(this.comboBoxThucDon);
            this.groupBox2.Controls.Add(this.textBoxSLNhanVien);
            this.groupBox2.Controls.Add(this.textBoxSoLuongBan);
            this.groupBox2.Controls.Add(this.comboBoxLoaiSanh);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.groupBox2.Location = new System.Drawing.Point(559, 59);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(540, 557);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin đặt tiệc";
            // 
            // comboBoxTenNhanVien
            // 
            this.comboBoxTenNhanVien.BackColor = System.Drawing.SystemColors.Window;
            this.comboBoxTenNhanVien.FormattingEnabled = true;
            this.comboBoxTenNhanVien.Location = new System.Drawing.Point(228, 42);
            this.comboBoxTenNhanVien.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxTenNhanVien.Name = "comboBoxTenNhanVien";
            this.comboBoxTenNhanVien.Size = new System.Drawing.Size(276, 33);
            this.comboBoxTenNhanVien.TabIndex = 10;
            this.comboBoxTenNhanVien.SelectedIndexChanged += new System.EventHandler(this.comboBoxTenNhanVien_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(26, 46);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Tên nhân viên";
            // 
            // comboBoxCa
            // 
            this.comboBoxCa.FormattingEnabled = true;
            this.comboBoxCa.Location = new System.Drawing.Point(228, 145);
            this.comboBoxCa.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxCa.Name = "comboBoxCa";
            this.comboBoxCa.Size = new System.Drawing.Size(276, 33);
            this.comboBoxCa.TabIndex = 38;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label18.Location = new System.Drawing.Point(33, 152);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(38, 25);
            this.label18.TabIndex = 37;
            this.label18.Text = "Ca";
            // 
            // comboBoxDichVu
            // 
            this.comboBoxDichVu.FormattingEnabled = true;
            this.comboBoxDichVu.Location = new System.Drawing.Point(228, 382);
            this.comboBoxDichVu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxDichVu.Name = "comboBoxDichVu";
            this.comboBoxDichVu.Size = new System.Drawing.Size(276, 33);
            this.comboBoxDichVu.TabIndex = 35;
            this.comboBoxDichVu.SelectedIndexChanged += new System.EventHandler(this.comboBoxDichVu_SelectedIndexChanged);
            // 
            // comboBoxThucDon
            // 
            this.comboBoxThucDon.FormattingEnabled = true;
            this.comboBoxThucDon.Location = new System.Drawing.Point(228, 320);
            this.comboBoxThucDon.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxThucDon.Name = "comboBoxThucDon";
            this.comboBoxThucDon.Size = new System.Drawing.Size(276, 33);
            this.comboBoxThucDon.TabIndex = 34;
            // 
            // textBoxSLNhanVien
            // 
            this.textBoxSLNhanVien.Location = new System.Drawing.Point(228, 262);
            this.textBoxSLNhanVien.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSLNhanVien.Name = "textBoxSLNhanVien";
            this.textBoxSLNhanVien.Size = new System.Drawing.Size(276, 30);
            this.textBoxSLNhanVien.TabIndex = 33;
            this.textBoxSLNhanVien.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSLNhanVien_KeyPress);
            // 
            // textBoxSoLuongBan
            // 
            this.textBoxSoLuongBan.Location = new System.Drawing.Point(228, 205);
            this.textBoxSoLuongBan.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSoLuongBan.Name = "textBoxSoLuongBan";
            this.textBoxSoLuongBan.Size = new System.Drawing.Size(276, 30);
            this.textBoxSoLuongBan.TabIndex = 27;
            this.textBoxSoLuongBan.TextChanged += new System.EventHandler(this.textBoxSoLuongBan_TextChanged);
            this.textBoxSoLuongBan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSoLuongBan_KeyPress);
            // 
            // comboBoxLoaiSanh
            // 
            this.comboBoxLoaiSanh.FormattingEnabled = true;
            this.comboBoxLoaiSanh.Location = new System.Drawing.Point(228, 94);
            this.comboBoxLoaiSanh.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxLoaiSanh.Name = "comboBoxLoaiSanh";
            this.comboBoxLoaiSanh.Size = new System.Drawing.Size(276, 33);
            this.comboBoxLoaiSanh.TabIndex = 11;
            this.comboBoxLoaiSanh.SelectedIndexChanged += new System.EventHandler(this.comboBoxLoaiSanh_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label16.Location = new System.Drawing.Point(33, 386);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 25);
            this.label16.TabIndex = 31;
            this.label16.Text = "Dịch vụ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label15.Location = new System.Drawing.Point(33, 325);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 25);
            this.label15.TabIndex = 30;
            this.label15.Text = "Thực đơn";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label14.Location = new System.Drawing.Point(33, 266);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(180, 25);
            this.label14.TabIndex = 29;
            this.label14.Text = "Số lượng nhân viên";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label13.Location = new System.Drawing.Point(33, 209);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(128, 25);
            this.label13.TabIndex = 28;
            this.label13.Text = "Số lượng bàn";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label12.Location = new System.Drawing.Point(33, 102);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 25);
            this.label12.TabIndex = 27;
            this.label12.Text = "Loại sảnh";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(423, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(393, 40);
            this.label1.TabIndex = 2;
            this.label1.Text = "Lập Hợp Đồng Đặt Tiệc";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(42, 9);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(159, 35);
            this.button2.TabIndex = 4;
            this.button2.Text = "Lập hợp đồng mới";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(611, 9);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 35);
            this.button3.TabIndex = 5;
            this.button3.Text = "Lưu ";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(860, 9);
            this.button6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(112, 35);
            this.button6.TabIndex = 8;
            this.button6.Text = "Thoát";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(338, 9);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(182, 35);
            this.button4.TabIndex = 9;
            this.button4.Text = "Xem Hợp Đồng";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // kryptonPalette1
            // 
            this.kryptonPalette1.FormStyles.FormCommon.StateCommon.Border.Color1 = System.Drawing.Color.Black;
            this.kryptonPalette1.FormStyles.FormCommon.StateCommon.Border.Color2 = System.Drawing.Color.Black;
            this.kryptonPalette1.FormStyles.FormCommon.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.FormStyles.FormCommon.StateCommon.Border.Rounding = 15;
            this.kryptonPalette1.FormStyles.FormCommon.StateCommon.Border.Width = 10;
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Color1 = System.Drawing.Color.Black;
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Color2 = System.Drawing.Color.Black;
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Rounding = 15;
            this.kryptonPalette1.FormStyles.FormMain.StateCommon.Border.Width = -2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Location = new System.Drawing.Point(12, 624);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1095, 49);
            this.panel1.TabIndex = 11;
            // 
            // LapHopDong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1132, 689);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "LapHopDong";
            this.Palette = this.kryptonPalette1;
            this.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Custom;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phần mềm quản lý tiệc cưới";
            this.Load += new System.EventHandler(this.LapHopDong_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxTenNhanVien;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxDienThoai;
        private System.Windows.Forms.TextBox textBoxDiaChi;
        private System.Windows.Forms.TextBox textBoxTenCoDau;
        private System.Windows.Forms.TextBox textBoxTenChuRe;
        private System.Windows.Forms.TextBox textBoxTenKhachHang;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBoxDichVu;
        private System.Windows.Forms.ComboBox comboBoxThucDon;
        private System.Windows.Forms.TextBox textBoxSLNhanVien;
        private System.Windows.Forms.TextBox textBoxSoLuongBan;
        private System.Windows.Forms.ComboBox comboBoxLoaiSanh;
        private System.Windows.Forms.ComboBox comboBoxCa;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label labelTienCoc;
        private System.Windows.Forms.TextBox textBoxTienCoc;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgayToChuc;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgayLap;
        private ComponentFactory.Krypton.Toolkit.KryptonPalette kryptonPalette1;
        private System.Windows.Forms.Panel panel1;
    }
}